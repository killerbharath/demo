package com.springsecurity.Assignment2Q2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2Q2Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2Q2Application.class, args);
	}

}
