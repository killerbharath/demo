function cal()
{
    var number = document.getElementById("number").value;
    var ans = (number - 32) * 5/9;
    
    // var ff = do / 9;

    // alert(ans);
    document.write(ans);

}