function myFunction()
{
    var custoName = document.getElementById("custoName").value;
    console.log(custoName);

    var email = document.getElementById("email").value;
    console.log(email);

    var cheese = document.getElementById("cheese").value;
    console.log(cheese);

    var pepperoni = document.getElementById("pepperoni").value;
    console.log(pepperoni);
}