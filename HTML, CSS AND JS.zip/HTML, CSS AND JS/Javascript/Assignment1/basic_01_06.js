function numRollsToGetSix()
{
    var y = Math.floor(Math.random() * 15);
    console.log(y);
}

numRollsToGetSix();
numRollsToGetSix();