function parity(a)
{
    if(a%2 == 0)
    {
        console.log("Even");
    }
    else
    {
        console.log("Odd");
    }
}

parity(1);
parity(2);