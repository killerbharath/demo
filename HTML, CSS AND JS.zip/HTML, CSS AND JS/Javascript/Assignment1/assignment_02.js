function star()
{
    var number = document.getElementById("number").value;
    var st = "";
    // var ff = do / 9;
    for(var i = 0;i<number;i++)
    {
        st += "*";
    }

    alert(st);
    // document.write(ans);
}