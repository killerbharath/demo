let model ="laptop"
let desknumber=1999;
let names="Vivek";
let laptop={
    model,
    desknumber,
    names
};
console.log(laptop.model);
console.log(laptop.desknumber);
console.log(laptop.names);