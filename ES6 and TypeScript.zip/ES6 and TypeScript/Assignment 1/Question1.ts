const pi = 3.25;
console.log(pi);
pi = 25;
console.log(pi);