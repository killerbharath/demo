let info=["Hello" ,"hii", 70,8]
let [name1,gender,age,height]=info
console.log(age)

var obj = {
    student: "vivek",
    address: {pin: 522403}
}

let {student,address} = obj;
console.log(address.pin);
