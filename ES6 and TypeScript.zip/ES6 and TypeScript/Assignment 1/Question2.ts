function check(a){
    if(a%2==0){
        let out = "Even";
    }
    else{
        let out = "odd";
    }
    return out;
};

console.log(check(25));